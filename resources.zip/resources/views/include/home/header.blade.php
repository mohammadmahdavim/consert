<header id="header" class="menu-top-left">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-4">
                <a href="/" id="logo" title="Tenguu" class="logo-image" data-bg-image="/home/images/favicon.jpg">کنسرت
                </a>
            </div>
            <div class="col-md-4 col-md-offset-2 col-sm-6 col-xs-8 phl0">
                <div class="header_author">

                    <div class="header_ticket">
                        <!-- Button trigger modal -->
                        <a   style="font-family: 'B Koodak'" id="header-search" href="/#" >
                            پیگیری بلیت
                        </a>

                        <!-- Modal -->
                    </div>
                    <a style="font-family: 'B Koodak'" href="/" >خانه</a>
                </div>

                <a href="javascript:;" id="header-search"></a>
                <div class="button_container" id="toggle">
                    <span class="top"></span>
                    <span class="middle"></span>
                    <span class="bottom"></span>
                </div>
                <div class="overlay" id="overlay">
                    <a href="javascript:;" class="close-window"></a>
                    <nav class="overlay-menu">
                        <ul >
                            <li ><a href="/">خانه</a></li>
                            <li><a href="/#">درحال اجرا</a></li>
                            <li><a href="/#">پیگیری بلیت</a></li>
                        </ul>
                    </nav>
                </div>            </div>
        </div>
    </div>
</header>
