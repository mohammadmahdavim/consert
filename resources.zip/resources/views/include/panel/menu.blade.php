<div class="side-menu">
    <div class="side-menu-body">
        <ul>
            <li class="side-menu-divider">فهرست</li>
            <li><a class="active" href="/panel/index"><i class="icon ti-home"></i> <span>داشبورد</span> </a></li>
            <li><a href="#"><i class="fa fa-sliders"></i> &nbsp;&nbsp;<span>مدیریت اسلایدر</span> </a>
                <ul>
                    <li><a href="/panel/slider">لیست </a></li>
                    <li><a href="/panel/slider/create">ایجاد </a></li>
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-archive"></i>&nbsp;&nbsp; <span>مدیریت سالن ها</span> </a>
                <ul>
                    <li><a href="/panel/salon">لیست </a></li>
                    <li><a href="/panel/salon/create">ایجاد </a></li>
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-list"></i>&nbsp;&nbsp; <span>مدیریت برنامه ها</span> </a>
                <ul>
                    <li><a href="/panel/program">لیست </a></li>
                    <li><a href="/panel/program/create">ایجاد </a></li>
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-users"></i> &nbsp;&nbsp;<span>مدیریت کاربران</span> </a>
                <ul>
                    <li><a href="/panel/users">لیست </a></li>
                    <li><a href="/panel/users/create">ایجاد </a></li>
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-money"></i>&nbsp;&nbsp; <span>مدیریت مالی</span> </a>
                <ul>
                    <li><a href="/panel/finance">لیست </a></li>

                </ul>
            </li>
            <li><a href="/panel/scan"><i class="fa fa-money"></i>&nbsp;&nbsp; <span>اسکن بلیط</span> </a>

            </li>
        </ul>
    </div>
</div>
